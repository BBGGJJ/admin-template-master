<template>
  <a-card class="task-item" type="inner">
    {{ content }}
  </a-card>
</template>

<script>
export default {
  name: 'TaskItem',
  // eslint-disable-next-line vue/require-prop-types
  props: ['content']
}
</script>

<style lang="less" scoped>
  .task-item{
    margin-bottom: 16px;
    box-shadow: 0 1;
    border-radius: 6px;
    & :hover{
      cursor: move;
      box-shadow:1px 2px;
      border-radius: 6px;
    }
  }
</style>
