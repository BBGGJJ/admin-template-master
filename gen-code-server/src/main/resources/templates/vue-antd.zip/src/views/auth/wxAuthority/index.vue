<template>
  <div class="app-container">
    <div class="filter-container">
      <el-form :inline="true" :model="listQuery" class="demo-form-inline">
        <el-form-item label="权限编码">
          <el-input v-model="listQuery.authCode" style="width: 140px" placeholder="权限编码" />
        </el-form-item>
        <el-form-item label="权限状态">
          <el-select v-model="listQuery.status" placeholder="权限状态">
            <el-option label="请选择" />
            <el-option label="有效" value="true" />
            <el-option label="无效" value="false" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button>
        </el-form-item>
        <el-form-item>
          <el-button
            class="filter-item"
            style="margin-left: 10px"
            type="primary"
            icon="el-icon-edit"
            @click="handleCreate"
          >添加</el-button>
        </el-form-item>
      </el-form>
    </div>

    <el-table
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%"
      @sort-change="sortChange"
    >
      <el-table-column
        label="ID"
        prop="id"
        sortable="custom"
        align="center"
        width="80"
        fixed
        :class-name="getSortClass('id')"
      >
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="权限编码" align="center">
        <template slot-scope="{row}">
          <span>{{ row.authCode }}</span>
        </template>
      </el-table-column>
      <el-table-column label="权限说明" align="center">
        <template slot-scope="{row}">
          <span>{{ row.remark }}</span>
        </template>
      </el-table-column>
      <el-table-column label="权限状态" align="center">
        <template slot-scope="{row}">
          <span>{{ row.status }}</span>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" align="center">
        <template slot-scope="{row}">
          <span>{{ row.createTime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="更新时间" align="center">
        <template slot-scope="{row}">
          <span>{{ row.updateTime }}</span>
        </template>
      </el-table-column>
      <el-table-column fixed="rigth" label="操作" align="center" width="230">
        <template slot-scope="{row}">
          <el-button
            v-if="row.status!='published'"
            size="mini"
            type="primary"
            @click="handleModify(row,'published')"
          >编辑</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="page.total>0"
      :total="page.total"
      :page.sync="page.pageNumber"
      :limit.sync="page.pageSize"
      @pagination="getList"
    />

    <el-dialog title="新增" :visible.sync="dialogFormVisible">
      <el-form
        ref="dataForm"
        :model="temp"
        :rules="rules"
        label-position="left"
        label-width="100px"
        style="width: 400px margin-left:50px"
      >
        <el-form-item label="权限编码" prop="authCode">
          <el-input v-model="temp.authCode" auto-complete="off" />
        </el-form-item>
        <el-form-item label="权限说明" prop="remark">
          <el-input v-model="temp.remark" auto-complete="off" />
        </el-form-item>
        <el-form-item label="权限状态" prop="status">
          <el-switch v-model="temp.status" on-text="有效" off-text="无效" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="saveData()">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Pagination from '@/components/Pagination'
export default {
  name: 'AuthWxAuthority',
  components: { Pagination },
  data () {
    return {
      tableKey: 0,
      list: null,
      sortOptions: [],
      listLoading: true,
      page: {
        pageSize: 20,
        total: 0,
        pageNumber: 1
      },
      listQuery: {
      },
      importanceOptions: [1, 2, 3],
      calendarTypeOptions: [],
      showReviewer: false,
      temp: {
        id: 0,
        authCode: '',
        remark: '',
        status: false,
        createTime: null,
        updateTime: null
      },
      rules: {
        authCode: [
          { required: true, message: '请输入权限编码', trigger: 'blur' }
        ],
        remark: [
          { required: true, message: '请输入权限说明', trigger: 'blur' }
        ],
        status: [
          { required: true, message: '请输入权限状态', trigger: 'change' }
        ]
      },
      dialogFormVisible: false,
      dialogPvVisible: false,
      downloadLoading: false
    }
  },
  created () {
    this.getList()
  },
  methods: {
    getList () {
      this.listLoading = false
      const query = this.listQuery
      const params = { }
      if (query.id) {
        params.id = query.id
      }
      if (query.authCode) {
        params.authCode = query.authCode
      }
      if (query.remark) {
        params.remark = query.remark
      }
      if (query.status) {
        params.status = query.status
      }
      if (query.createTime) {
        params.createTime = query.createTime
      }
      if (query.updateTime) {
        params.updateTime = query.updateTime
      }
      params.page = this.page
      this.$store.dispatch('authWxAuthority/queryList', { params }).then(response => {
        this.list = response.data
        this.page = response.page
        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 1000)
      })
    },
    handleFilter () {
      this.page.pageNumber = 1
      this.getList()
    },
    handleModify (row, status) {
      this.listLoading = false
      const { id } = row
      this.$store.dispatch('authWxAuthority/fetchWxAuthority', id).then(response => {
        this.temp = response.data
        this.dialogStatus = 'update'
        this.dialogFormVisible = true
      })
    },
    saveData () {
      this.$refs['dataForm'].validate(valid => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          if (this.dialogStatus === 'create') {
            this.$store.dispatch('authWxAuthority/createWxAuthority', tempData).then(() => {
              this.getList()
              this.dialogFormVisible = false
            })
          }
          if (this.dialogStatus === 'update') {
            this.$store.dispatch('authWxAuthority/updateWxAuthority', tempData).then(() => {
              const index = this.list.findIndex(v => v.id === this.temp.id)
              this.list.splice(index, 1, this.temp)
              this.dialogFormVisible = false
              this.$notify({
                title: 'Success',
                message: '更新成功!',
                type: 'success',
                duration: 2000
              })
            })
          }
        }
      })
    },
    sortChange (data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    sortByID (order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    resetTemp () {
      this.temp = {}
    },
    handleCreate () {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    handleDelete (row, index) {
      this.$store.dispatch('authWxAuthority/deleteWxAuthority', row.id).then(() => {
        this.list.splice(index, 1)
        this.dialogFormVisible = false
        this.$notify({
          title: 'Success',
          message: '删除成功！',
          type: 'success',
          duration: 2000
        })
      })
    },
    getSortClass: function (key) {
      const sort = this.listQuery.sort
      return sort === `+ ${key}` ? 'ascending' : 'descending'
    }
  }
}
</script>

<style scoped>
.line {
  text-align: center
}
.filter-container {
  margin-bottom: 20px
}
</style>
