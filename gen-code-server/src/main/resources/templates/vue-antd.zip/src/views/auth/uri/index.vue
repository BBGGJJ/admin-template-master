<template>
  <div class="app-container">
    <div class="filter-container">
      <el-form :inline="true" :model="listQuery" class="demo-form-inline">
        <el-form-item label="项目名称" required="true">
          <el-select
            v-model="listQuery.appCode"
            filterable
            remote
            :remote-method="appSourceSearch"
            placeholder="请输入系统名或者编码"
            no-data-text="无匹配数据"
            maxlength="100"
            clearable
            @change="remoteMethod"
          >
            <el-option
              v-for="item in appSourceList"
              :key="item.id"
              v-bind="item.id"
              :value="item.id"
              :label="`${item.name}(${item.appCode})`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="uri类型" prop="type">
          <el-select v-model="listQuery.type" placeholder="uri类型">
            <el-option label="请选择" />
            <el-option label="页面" value="1" />
            <el-option label="接口" value="2" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button class="filter-item" type="primary" icon="el-icon-search" @click="queryTree">搜索</el-button>
        </el-form-item>
        <el-form-item>
          <el-button class="filter-item" type="primary" icon="el-icon-search" @click="showCreate">新增uri</el-button>
        </el-form-item>
        <el-form-item>
          <el-button v-if="level > 1" class="filter-item" type="primary" icon="el-icon-search" @click="prevNode">返回</el-button>
        </el-form-item>
      </el-form>
    </div>
    <div>
      <table class="el-table__header draggable_table">
        <thead class="thead-dark has-gutter">
          <tr>
            <th scope="col" width="100"><div class="cell">Id</div></th>
            <th><div class="cell">url路径</div></th>
            <th><div class="cell">英文编码</div></th>
            <th><div class="cell">图标</div></th>
            <th><div class="cell">权限名称</div></th>
            <th><div class="cell">权限描述</div></th>
            <th><div class="cell">uri类型</div></th>
            <th><div class="cell">创建时间</div></th>
            <th><div class="cell">修改时间</div></th>
            <th><div class="cell">操作</div></th>
          </tr>
        </thead>
        <draggable v-model="currList" tag="tbody" class="el-table__body" @change="change">
          <tr v-for="item in currList" :key="item.id">
            <td scope="row"><div class="cell">{{ item.id }}</div></td>
            <td><div class="cell">{{ item.path }}</div></td>
            <td><div class="cell">{{ item.uriCode }}</div></td>
            <td><div class="cell"><span><a-icon :type="item.icon" /></span></div></td>
            <td><div class="cell">{{ item.uriName }}</div></td>
            <td><div class="cell">{{ item.uriDescription }}</div></td>
            <td><div class="cell">
              <el-tag
                :type="item.type === 1 ? 'success' : 'danger'"
                disable-transitions
              >{{ typeFormatter(item) }}</el-tag></div>
            </td>
            <td><div class="cell"> <span>{{ item.createTime }}</span></div></td>
            <td><div class="cell">{{ item.updateTime }}</div></td>
            <td><div class="cell">
              <el-button
                v-if="level < 2"
                type="text"
                size="mini"
                @click="() => manageChild(item)"
              >
                管理子权限
              </el-button>
              <el-button
                type="text"
                size="mini"
                @click="() => handleDelete(item, $index)"
              >
                删除权限
              </el-button>
              <el-button
                type="text"
                size="mini"
                @click="() => handleEdit(item, $index)"
              >
                编辑权限
              </el-button></div>
            </td>
          </tr>
        </draggable>
      </table>
    </div>
    <!-- <el-table
      :key="tableKey"
      :data="tree"
      border
      style="width: 100%"
      row-key="id"
      default-expand-all
      :tree-props="{children: 'childs', hasChildren: 'hasChildren'}"
    >
      <el-table-column
        label="ID"
        prop="id"
        fixed
        align="center"
        width="80"
        :class-name="getSortClass('id')"
      >
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="url路径" align="center">
        <template slot-scope="{row}">
          <span>{{ row.path }}</span>
        </template>
      </el-table-column>
      <el-table-column label="英文编码" align="center">
        <template slot-scope="{row}">
          <span>{{ row.uriCode }}</span>
        </template>
      </el-table-column>
      <el-table-column label="图标" align="center">
        <template slot-scope="{row}">
          <span><a-icon :type="row.icon" /></span>
        </template>
      </el-table-column>
      <el-table-column label="权限名称" align="center">
        <template slot-scope="{row}">
          <span>{{ row.uriName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="权限描述" align="center">
        <template slot-scope="{row}">
          <span>{{ row.uriDescription }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="uri类型"
        align="center"
        width="80"
        :formatter="statusFormatter"
      >
        <template slot-scope="{row}">
          <el-tag
            :type="row.type === 1 ? 'success' : 'danger'"
            disable-transitions
          >{{ typeFormatter(row) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" align="center">
        <template slot-scope="{row}">
          <span>{{ row.createTime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="修改时间" align="center">
        <template slot-scope="{row}">
          <span>{{ row.updateTime }}</span>
        </template>
      </el-table-column>
      <el-table-column fixed="right" label="操作" align="center" width="230">
        <template slot-scope="{row,$index}">
          <el-button
            type="text"
            size="mini"
            @click="() => showCreate(row)"
          >
            新增子权限
          </el-button>
          <el-button
            type="text"
            size="mini"
            @click="() => showCreate(row)"
          >
            管理子权限
          </el-button>
          <el-button
            type="text"
            size="mini"
            @click="() => handleDelete(row, $index)"
          >
            删除权限
          </el-button>
          <el-button
            type="text"
            size="mini"
            @click="() => handleEdit(row, $index)"
          >
            编辑权限
          </el-button>
        </template>
      </el-table-column>
    </el-table> -->
    <el-dialog :title="dialogStatus==='create'? '新增' :'编辑'" :visible.sync="dialogFormVisible">
      <el-form
        ref="dataForm"
        :model="temp"
        :rules="rules"
        label-position="left"
        label-width="100px"
        style="width: 400px margin-left:100px"
      >
        <el-form-item label="项目名称" prop="appCode">
          <el-select
            v-model="temp.appCode"
            filterable
            remote
            :remote-method="appSourceSearch"
            placeholder="请输入系统名或者编码"
            no-data-text="无匹配数据"
            maxlength="100"
            clearable
            @change="remoteMethod"
          >
            <el-option
              v-for="item in appSourceList"
              :key="item.id"
              v-bind="item.id"
              :value="item.id"
              :label="`${item.name}(${item.appCode})`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="url路径" prop="path">
          <el-input v-model="temp.path" auto-complete="off" />
        </el-form-item>
        <el-form-item label="权限编码" prop="uriCode">
          <el-input v-model="temp.uriCode" auto-complete="off" />
        </el-form-item>
        <el-form-item label="权限名称" prop="uriName">
          <el-input v-model="temp.uriName" auto-complete="off" />
        </el-form-item>
        <el-form-item label="权限描述" prop="uriDescription">
          <el-input v-model="temp.uriDescription" auto-complete="off" />
        </el-form-item>
        <el-form-item label="uri类型" prop="type">
          <el-select v-model="temp.type" placeholder="uri类型">
            <el-option label="请选择" />
            <el-option label="页面" value="1" />
            <el-option label="接口" value="2" />
          </el-select>
        </el-form-item>
        <el-form-item label="图标" prop="icon">
          <el-select v-model="temp.icon" placeholder="图标">
            <el-option label="请选择" />
            <el-option v-for="item in iconList" :key="item" :value="item">
              <a-icon :type="item" />
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="saveData()">保存</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Draggable from 'vuedraggable'
export default {
  name: 'AuthUri',
  components: { Draggable },
  data () {
    return {
      tableKey: 0,
      tree: [],
      currList: [],
      sortOptions: [],
      level: 1,
      listLoading: true,
      currAppendData: {},
      parnetUris: [],
      appSourceList: [],
      iconList: [
        'dashboard',
        'ordered-list',
        'bug',
        'bar-chart',
        'wechat',
        'account-book',
        'alert',
        'api',
        'edit',
        'form',
        'appstore',
        'bank',
        'bell',
        'book',
        'build',
        'calendar',
        'cloud',
        'code',
        'contacts',
        'container',
        'control',
        'credit-card',
        'crown',
        'database',
        'flag',
        'fire',
        'gift',
        'home',
        'heart',
        'message',
        'profile',
        'project',
        'pushpin',
        'rest',
        'rocket',
        'star',
        'setting',
        'tool',
        'apartment',
        'audit',
        'cluster',
        'desktop',
        'global',
        'gateway',
        'history',
        'import',
        'user',
        'monitor',
        'filter',
        'link',
        'security-scan',
        'block',
        'key'
      ],
      page: {
        pageSize: 200,
        total: 0,
        pageNumber: 1
      },
      listQuery: {
      },
      rules: {
        path: [
          { required: true, message: '必须填写uri路径！', trigger: 'blur' }
        ],
        uriName: [
          { required: true, message: '必须填写权限名称', trigger: 'blur' }
        ],
        uriCode: [
          { required: true, message: '必须填写权限编码', trigger: 'blur' }
        ],
        appCode: [
          { required: true, message: '系统名称必须填写', trigger: 'blur' }
        ],
        type: [
          { required: true, message: '请输入属性编码', trigger: 'blur' }
        ]
      },
      importanceOptions: [1, 2, 3],
      calendarTypeOptions: [],
      showReviewer: false,
      temp: {
        id: 0,
        path: '',
        uriName: '',
        uriDescription: '',
        parentId: 0,
        appCode: 0,
        type: 0,
        createTime: null,
        updateTime: null,
        parentUriName: ''
      },
      props: {
        label: 'uriName',
        children: 'childs'
      },
      dialogFormVisible: false,
      dialogPvVisible: false,
      downloadLoading: false
    }
  },
  created () {
  },
  methods: {
    queryTree () {
      const params = {}
      params.appCode = this.listQuery.appCode
      params.page = this.page
      this.$store.dispatch('authUri/queryTree', { ...params }).then(response => {
        this.tree = response || []
        this.level = 1
        this.parnetUris = []
        this.currList = this.tree
      })
    },
    appSourceSearch (value, id) {
      const params = {}
      params.page = this.page
      params.suggest = value
      params.id = id
      params.status = true
      this.$store.dispatch('sysAppsource/suggest', params).then((response) => {
        this.appSourceList = response.data
      })
    },
    change () {
      let i = 0
      const params = this.currList.map(e => {
        i = i + 1
        return { id: e.id, index: i }
      })
      this.$store.dispatch('authUri/updateIndex', params)
    },
    manageChild (item) {
      this.parnetUris.push(item)
      this.level = this.level + 1
      this.currList = item.childs || []
    },
    typeFormatter (row, column) {
      return row.type === 1 ? '页面' : '服务接口'
    },
    prevNode () {
      this.parnetUris = []
      this.level = this.level - 1
      this.currList = this.tree
    },
    handleFilter () {
      this.page.pageNumber = 1
      this.getList()
    },
    handleEdit (row, status) {
      this.listLoading = false
      const { id } = row
      this.$store.dispatch('authUri/fetchUri', id).then(response => {
        this.temp = response.data
        this.dialogStatus = 'update'
        this.dialogFormVisible = true
      })
    },
    saveData (data) {
      this.$refs['dataForm'].validate(valid => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          if (this.level > 1) {
            tempData.parentId = (this.parnetUris[this.level - 2] || {}).id || 0
          }
          tempData.appCode = this.listQuery.appCode
          if (this.dialogStatus === 'create') {
            this.$store.dispatch('authUri/createUri', tempData).then((data) => {
              this.currList.push(data)
              this.dialogFormVisible = false
            })
          }
          if (this.dialogStatus === 'update') {
            this.$store.dispatch('authUri/updateUri', tempData).then(() => {
              for (var i = 0; i < this.currList.length; i++) {
                if (this.currList[i].id === tempData.id) {
                  this.currList[i] = tempData
                  break
                }
              }
              this.dialogFormVisible = false
              this.$notify({
                title: 'Success',
                message: '更新成功!',
                type: 'success',
                duration: 2000
              })
            })
          }
        }
      })
    },
    sortChange (data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    sortByID (order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    resetTemp () {
      this.temp = {}
    },
    showCreate (node) {
      this.resetTemp()
      if (this.listQuery.appCode) {
        this.temp.appCode = this.listQuery.appCode
      }
      const data = node || {}
      this.dialogStatus = 'create'
      this.temp.parentId = data.id || 0
      this.temp.parentUriName = node.name
      this.dialogFormVisible = true
      this.currAppendData = node
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    handleDelete (row, index) {
      if (row.childs && row.childs.length > 0) {
        this.$notify({
          title: '删除失败',
          message: '请先删除子节点！',
          type: 'error',
          duration: 2000
        })
        return
      }
      this.$store.dispatch('authUri/deleteUri', row.id).then(() => {
        this.removeTree(this.tree, row.id)
        this.dialogFormVisible = false
        this.$notify({
          title: 'Success',
          message: '删除成功！',
          type: 'success',
          duration: 2000
        })
      })
    },
    removeTree (nodes, id) {
      if (!nodes) {
        return false
      }
      for (const i in nodes) {
        if (nodes[i].id === id) {
          nodes.splice(i, 1)
          return true
        }
        if (this.removeTree(nodes[i].childs, id)) {
          return true
        }
      }
    },
    updateTree (nodes, id, temp) {
      if (!nodes) {
        return false
      }
      for (const i in nodes) {
        if (nodes[i].id === id) {
          nodes.splice(i, 1, temp)
          return true
        }
        if (this.removeTree(nodes[i].childs, id)) {
          return true
        }
      }
    },
    getSortClass: function (key) {
      const sort = this.listQuery.sort
      return sort === `+ ${key}` ? 'ascending' : 'descending'
    }
  }
}
</script>

<style scoped>
.line {
  text-align: center
}
.draggable_table {
  width: 100%;
  background-color: aliceblue;
}
.draggable_table td{
  padding: 1px 0;
}
.filter-container {
  margin-bottom: 20px
}
.custom-tree-node {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    padding-right: 8px;
}
</style>
