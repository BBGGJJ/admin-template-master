<template>
  <div class="app-container">
    <div class="filter-container">
      <el-form :inline="true" :model="listQuery" class="demo-form-inline">
        <el-form-item label="关联系统">
          <el-select
            v-model="listQuery.appCode"
            filterable
            remote
            :remote-method="appSourceSearch"
            placeholder="请输入系统名或者编码"
            no-data-text="无匹配数据"
            maxlength="100"
            clearable
            @change="remoteMethod"
          >
            <el-option
              v-for="item in appSourceList"
              :key="item.id"
              v-bind="item.id"
              :value="item.id"
              :label="`${item.name}(${item.appCode})`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="用户姓名">
          <el-select
            v-model="listQuery.userId"
            filterable
            remote
            :remote-method="usersSearch"
            placeholder="请输入用户姓名"
            no-data-text="无匹配数据"
            maxlength="100"
            clearable
            @change="remoteMethod"
          >
            <el-option
              v-for="item in usersList"
              :key="item.userId"
              v-bind="item.userId"
              :value="item.userId"
              :label="`${item.userName}(${item.nickName})`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="listQuery.status" placeholder="状态">
            <el-option label="请选择" />
            <el-option label="有效" value="true" />
            <el-option label="无效" value="false" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button>
        </el-form-item>
        <el-form-item>
          <el-button
            class="filter-item"
            style="margin-left: 10px"
            type="primary"
            icon="el-icon-edit"
            @click="handleCreate"
          >添加</el-button>
        </el-form-item>
      </el-form>
    </div>

    <el-table
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%"
      @sort-change="sortChange"
    >
      <el-table-column
        label="ID"
        prop="id"
        sortable="custom"
        align="center"
        width="80"
        :class-name="getSortClass('id')"
      >
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="用户姓名" align="center">
        <template slot-scope="{row}">
          <span>{{ row.userName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="系统名" align="center">
        <template slot-scope="{row}">
          <span>{{ row.appsourceName }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="状态"
        align="center"
        width="80"
        :formatter="statusFormatter"
      >
        <template slot-scope="{row}">
          <el-tag
            :type="row.status === true ? 'success' : 'danger'"
            disable-transitions
          >{{ statusFormatter(row) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" align="center">
        <template slot-scope="{row}">
          <span>{{ row.createTime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="修改时间" align="center">
        <template slot-scope="{row}">
          <span>{{ row.updateTime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="230" class-name="small-padding fixed-width">
        <template slot-scope="{row,$index}">
          <el-button
            size="mini"
            type="primary"
            @click="authority(row, $index)"
          >分配权限</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="page.total>0"
      :total="page.total"
      :page.sync="page.pageNumber"
      :limit.sync="page.pageSize"
      @pagination="getList"
    />

    <el-dialog title="新增关联用户" :visible.sync="dialogFormVisible">
      <el-form
        ref="dataForm"
        :model="temp"
        :rules="rules"
        label-position="left"
        label-width="70px"
        style="width: 400px margin-left:50px"
      >
        <el-form-item label="添加用户" prop="userId">
          <el-select
            v-model="temp.userId"
            filterable
            remote
            :remote-method="usersSearch"
            placeholder="请输入用户姓名"
            no-data-text="无匹配数据"
            maxlength="100"
            clearable
            @change="remoteMethod"
          >
            <el-option
              v-for="item in usersList"
              :key="item.userId"
              v-bind="item.userId"
              :value="item.userId"
              :label="`${item.userName}(${item.nickName})`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="关联系统" prop="appsourceId">
          <el-select
            v-model="temp.appsourceId"
            filterable
            remote
            :remote-method="appSourceSearch"
            placeholder="请输入系统名或者编码"
            no-data-text="无匹配数据"
            maxlength="100"
            clearable
            @change="remoteMethod"
          >
            <el-option
              v-for="item in appSourceList"
              :key="item.id"
              v-bind="item.id"
              :value="item.id"
              :label="`${item.name}(${item.appCode})`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-select v-model="temp.status" placeholder="状态">
            <el-option label="请选择" />
            <el-option label="有效" value="true" />
            <el-option label="无效" value="false" />
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="saveData()">提交</el-button>
      </div>
    </el-dialog>
    <el-dialog title="分配权限" :visible.sync="dialogRoleVisible">
      <el-form
        ref="dataForm"
        :model="temp"
        label-position="left"
        label-width="100px"
        style="width: 400px margin-left:50px"
      >
        <el-form-item>
          <template>
            <el-transfer
              v-model="roleValue"
              :titles="['待分配权限', '已分配权限']"
              filterable
              :filter-method="filterMethod"
              filter-placeholder="请输入角色名称"
              :data="roleList"
            />
          </template>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogRoleVisible = false">取消</el-button>
        <el-button type="primary" @click="saveUserRole()">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Pagination from '@/components/Pagination'
export default {
  name: 'AuthAuthUser',
  components: { Pagination },
  data () {
    return {
      tableKey: 0,
      list: null,
      sortOptions: [],
      appSourceList: [],
      usersList: [],
      roleList: [],
      roleValue: [],
      listLoading: true,
      page: {
        pageSize: 20,
        total: 0,
        pageNumber: 1
      },
      listQuery: {
      },
      rules: {
        status: [
          { required: true, message: '必须选择状态！', trigger: 'blur' }
        ],
        userId: [
          { required: true, message: '必须选择用户', trigger: 'blur' }
        ],
        appsourceId: [
          { required: true, message: '系统名称必须填写', trigger: 'blur' }
        ]
      },
      importanceOptions: [1, 2, 3],
      calendarTypeOptions: [],
      showReviewer: false,
      temp: {
        id: 0,
        userId: false,
        appsourceId: '',
        status: '',
        createTime: null,
        updateTime: null
      },
      dialogFormVisible: false,
      dialogRoleVisible: false,
      downloadLoading: false
    }
  },
  created () {
    this.getList()
  },
  methods: {
    getList () {
      this.listLoading = false
      const query = this.listQuery
      const params = { }
      if (query.id) {
        params.id = query.id
      }
      if (query.userId) {
        params.userId = query.userId
      }
      if (query.appsourceId) {
        params.appsourceId = query.appsourceId
      }
      if (query.status) {
        params.status = query.status
      }
      if (query.createTime) {
        params.createTime = query.createTime
      }
      if (query.updateTime) {
        params.updateTime = query.updateTime
      }
      params.page = this.page
      this.$store.dispatch('authAuthUser/queryList', { params }).then(response => {
        this.list = response.data
        this.page = response.page
        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 1000)
      })
    },
    handleFilter () {
      this.page.pageNumber = 1
      this.getList()
    },
    statusFormatter (row, column) {
      return row.status ? '有效' : '无效'
    },
    handleModify (row, status) {
      this.listLoading = false
      const { id } = row
      this.$store.dispatch('authAuthUser/fetchAuthUser', id).then(response => {
        this.temp = response.data
        this.dialogStatus = 'update'
        this.dialogFormVisible = true
      })
    },
    authority (row, status) {
      this.listLoading = false
      const params = { }
      params.appCode = row.appsourceId
      params.page = this.page
      params.page.pageSize = 2000
      this.$store.dispatch('authRole/queryList', { params }).then(response => {
        this.roleList = response.data
        const roleList = []
        const { data } = response
        for (let i = 0; i < data.length; i++) {
          roleList.push({
            key: data[i].id,
            label: data[i].roleName,
            disabled: false
          })
        }
        this.roleList = roleList
        this.$store.dispatch('authAuthUser/fetchAuthUser', row.id).then(response => {
          this.temp = response.data
          this.roleValue = this.temp.roleIds
          this.dialogStatus = 'update'
          this.dialogRoleVisible = true
          setTimeout(() => {
            this.listLoading = false
          }, 1.5 * 1000)
        })
      })
    },
    filterMethod (query, item) {
      return item.label.indexOf(query) > -1
    },
    saveData () {
      this.$refs['dataForm'].validate(valid => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          if (this.dialogStatus === 'create') {
            this.$store.dispatch('authAuthUser/createAuthUser', tempData).then(() => {
              this.getList()
              this.dialogFormVisible = false
            })
          }
          if (this.dialogStatus === 'update') {
            this.$store.dispatch('authAuthUser/updateAuthUser', tempData).then(() => {
              const index = this.list.findIndex(v => v.id === this.temp.id)
              this.list.splice(index, 1, this.temp)
              this.dialogFormVisible = false
              this.$notify({
                title: 'Success',
                message: '更新成功!',
                type: 'success',
                duration: 2000
              })
            })
          }
        }
      })
    },
    saveUserRole () {
      const param = {}
      param.id = this.temp.id
      param.roleIds = this.roleValue
      this.$store.dispatch('authAuthUser/updateUserRole', param).then(() => {
        this.getList()
        this.dialogRoleVisible = false
      })
    },
    sortChange (data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    sortByID (order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    resetTemp () {
      this.temp = {}
    },
    handleCreate () {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    handleDelete (row, index) {
      this.$store.dispatch('authAuthUser/deleteAuthUser', row.id).then(() => {
        this.list.splice(index, 1)
        this.dialogFormVisible = false
        this.$notify({
          title: 'Success',
          message: '删除成功！',
          type: 'success',
          duration: 2000
        })
      })
    },
    appSourceSearch (value, id) {
      const params = {}
      params.page = this.page
      params.suggest = value
      params.id = id
      params.status = true
      this.$store.dispatch('sysAppsource/suggest', params).then((response) => {
        this.appSourceList = response.data
      })
    },
    usersSearch (value, id) {
      this.$store.dispatch('userUser/suggest', value).then((response) => {
        this.usersList = response.data
      })
    },
    getSortClass: function (key) {
      const sort = this.listQuery.sort
      return sort === `+ ${key}` ? 'ascending' : 'descending'
    }
  }
}
</script>

<style scoped>
.line {
  text-align: center
}
.filter-container {
  margin-bottom: 20px
}
</style>
