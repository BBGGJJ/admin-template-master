<template>
  <div class="app-container">
    <div class="filter-container">
      <el-form :inline="true" :model="listQuery" class="demo-form-inline">
        <el-form-item label="状态">
          <el-select v-model="listQuery.status" placeholder="状态">
            <el-option label="请选择" />
            <el-option label="有效" value="true" />
            <el-option label="无效" value="false" />
          </el-select>
        </el-form-item>
        <el-form-item label="关联系统">
          <el-select
            v-model="listQuery.appId"
            filterable
            remote
            :remote-method="appSourceSearch"
            placeholder="请输入系统名或者编码"
            no-data-text="无匹配数据"
            maxlength="100"
            clearable
            @change="remoteMethod"
          >
            <el-option
              v-for="item in appSourceList"
              :key="item.id"
              v-bind="item.id"
              :value="item.id"
              :label="`${item.name}(${item.appCode})`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="白名单路径">
          <el-input v-model="listQuery.excludeUri" style="width: 140px" placeholder="白名单路径" />
        </el-form-item>
        <el-form-item>
          <el-button class="filter-item" type="primary" icon="el-icon-search" @click="handleFilter">搜索</el-button>
        </el-form-item>
        <el-form-item>
          <el-button
            class="filter-item"
            style="margin-left: 10px"
            type="primary"
            icon="el-icon-edit"
            @click="handleCreate"
          >添加</el-button>
        </el-form-item>
      </el-form>
    </div>
    <el-table
      :key="tableKey"
      v-loading="listLoading"
      :data="list"
      border
      fit
      highlight-current-row
      style="width: 100%"
      @sort-change="sortChange"
    >
      <el-table-column
        label="ID"
        prop="id"
        sortable="custom"
        align="center"
        width="80"
        :class-name="getSortClass('id')"
      >
        <template slot-scope="{row}">
          <span>{{ row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="状态"
        align="center"
        width="80"
        :formatter="statusFormatter"
      >
        <template slot-scope="{row}">
          <el-tag
            :type="row.status === true ? 'success' : 'danger'"
            disable-transitions
          >{{ statusFormatter(row) }}</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="系统编码" align="center">
        <template slot-scope="{row}">
          <span>{{ row.appCode }}</span>
        </template>
      </el-table-column>
      <el-table-column label="系统名称" align="center">
        <template slot-scope="{row}">
          <span>{{ row.appName }}</span>
        </template>
      </el-table-column>
      <el-table-column label="白名单路径" align="center">
        <template slot-scope="{row}">
          <span>{{ row.excludeUri }}</span>
        </template>
      </el-table-column>
      <el-table-column label="备注" align="center">
        <template slot-scope="{row}">
          <span>{{ row.desc }}</span>
        </template>
      </el-table-column>
      <el-table-column label="创建时间" align="center">
        <template slot-scope="{row}">
          <span>{{ row.createTime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="修改时间" align="center">
        <template slot-scope="{row}">
          <span>{{ row.updateTime }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" align="center" width="230">
        <template slot-scope="{row,$index}">
          <el-button
            v-if="row.status!='published'"
            size="mini"
            type="primary"
            @click="handleModify(row,'published')"
          >编辑</el-button>
          <el-button
            size="mini"
            type="danger"
            @click="handleDelete(row,$index)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <Pagination
      v-show="page.total>0"
      :total="page.total"
      :page.sync="page.pageNumber"
      :limit.sync="page.pageSize"
      @pagination="getList"
    />

    <el-dialog title="新增" :visible.sync="dialogFormVisible">
      <el-form
        ref="dataForm"
        :model="temp"
        :rules="rules"
        label-position="left"
        label-width="120px"
        style="width: 400px margin-left:50px"
      >
        <el-form-item label="状态" prop="status">
          <el-select v-model="temp.status" placeholder="状态">
            <el-option label="请选择" />
            <el-option label="有效" value="true" />
            <el-option label="无效" value="false" />
          </el-select>
        </el-form-item>
        <el-form-item label="系统编号" prop="appId">
          <el-select
            v-model="temp.appId"
            filterable
            remote
            :remote-method="appSourceSearch"
            placeholder="请输入系统名或者编码"
            no-data-text="无匹配数据"
            maxlength="100"
            clearable
            @change="remoteMethod"
          >
            <el-option
              v-for="item in appSourceList"
              :key="item.id"
              v-bind="item.id"
              :value="item.id"
              :label="`${item.name}(${item.appCode})`"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="白名单路径" prop="excludeUri">
          <el-input v-model="temp.excludeUri" auto-complete="off" />
        </el-form-item>
        <el-form-item label="备注" prop="desc">
          <el-input v-model="temp.desc" auto-complete="off" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取消</el-button>
        <el-button type="primary" @click="saveData()">提交</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Pagination from '@/components/Pagination'
export default {
  name: 'AuthUriWhiteList',
  components: { Pagination },
  data () {
    return {
      tableKey: 0,
      list: null,
      sortOptions: [],
      listLoading: true,
      appSourceList: [],
      page: {
        pageSize: 20,
        total: 0,
        pageNumber: 1
      },
      listQuery: {
      },
      importanceOptions: [1, 2, 3],
      calendarTypeOptions: [],
      showReviewer: false,
      temp: {
        id: 0,
        status: false,
        appId: 0,
        excludeUri: '',
        desc: '',
        createTime: null,
        updateTime: null
      },
      rules: {
        status: [
          { required: true, message: '请输入状态', trigger: 'blur' }
        ],
        appId: [
          { required: true, message: '请选择系统', trigger: 'change' }
        ],
        excludeUri: [
          { required: true, message: '路径不能为空', trigger: 'change' }
        ]
      },
      dialogFormVisible: false,
      dialogPvVisible: false,
      downloadLoading: false
    }
  },
  created () {
    this.getList()
  },
  methods: {
    getList () {
      this.listLoading = false
      const query = this.listQuery
      const params = { }
      if (query.id) {
        params.id = query.id
      }
      if (query.status) {
        params.status = query.status
      }
      if (query.appId) {
        params.appId = query.appId
      }
      if (query.excludeUri) {
        params.excludeUri = query.excludeUri
      }
      if (query.desc) {
        params.desc = query.desc
      }
      if (query.createTime) {
        params.createTime = query.createTime
      }
      if (query.updateTime) {
        params.updateTime = query.updateTime
      }
      params.page = this.page
      this.$store.dispatch('authUriWhiteList/queryList', { params }).then(response => {
        this.list = response.data
        this.page = response.page
        setTimeout(() => {
          this.listLoading = false
        }, 1.5 * 1000)
      })
    },
    handleFilter () {
      this.page.pageNumber = 1
      this.getList()
    },
    handleModify (row, status) {
      this.listLoading = false
      const { id } = row
      this.$store.dispatch('authUriWhiteList/fetchUriWhiteList', id).then(response => {
        this.temp = response.data
        this.dialogStatus = 'update'
        this.dialogFormVisible = true
      })
    },
    saveData () {
      this.$refs['dataForm'].validate(valid => {
        if (valid) {
          const tempData = Object.assign({}, this.temp)
          if (this.dialogStatus === 'create') {
            this.$store.dispatch('authUriWhiteList/createUriWhiteList', tempData).then(() => {
              this.getList()
              this.dialogFormVisible = false
            })
          }
          if (this.dialogStatus === 'update') {
            this.$store.dispatch('authUriWhiteList/updateUriWhiteList', tempData).then(() => {
              const index = this.list.findIndex(v => v.id === this.temp.id)
              this.list.splice(index, 1, this.temp)
              this.dialogFormVisible = false
              this.$notify({
                title: 'Success',
                message: '更新成功!',
                type: 'success',
                duration: 2000
              })
            })
          }
        }
      })
    },
    sortChange (data) {
      const { prop, order } = data
      if (prop === 'id') {
        this.sortByID(order)
      }
    },
    sortByID (order) {
      if (order === 'ascending') {
        this.listQuery.sort = '+id'
      } else {
        this.listQuery.sort = '-id'
      }
      this.handleFilter()
    },
    resetTemp () {
      this.temp = {}
    },
    handleCreate () {
      this.resetTemp()
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['dataForm'].clearValidate()
      })
    },
    handleDelete (row, index) {
      this.$store.dispatch('authUriWhiteList/deleteUriWhiteList', row.id).then(() => {
        this.list.splice(index, 1)
        this.dialogFormVisible = false
        this.$notify({
          title: 'Success',
          message: '删除成功！',
          type: 'success',
          duration: 2000
        })
      })
    },
    statusFormatter (row, column) {
      return row.status ? '有效' : '无效'
    },
    appSourceSearch (value, id) {
      const params = {}
      params.page = this.page
      params.suggest = value
      params.id = id
      params.status = true
      this.$store.dispatch('sysAppsource/suggest', params).then((response) => {
        this.appSourceList = response.data
      })
    },
    getSortClass: function (key) {
      const sort = this.listQuery.sort
      return sort === `+ ${key}` ? 'ascending' : 'descending'
    }
  }
}
</script>

<style scoped>
.line {
  text-align: center
}
.filter-container {
  margin-bottom: 20px
}
</style>
