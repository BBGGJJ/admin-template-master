import { constantRouterMap } from '@/config/router.config'
import { fetchUriTree } from '@/api/login'
// import { BasicLayout } from '@/layouts'
// const filterAsyncRouter = (uris, level) => { // 遍历后台传来的路由字符串，转换为组件对象
//   const routers = []
//   uris.forEach(uri => {
//     const router = {}
//     const { path = '' } = uri
//     if (path === '/') {
//       uri.redirect = '/dashboard'
//     }
//     if (level <= 1) {
//       router.component = BasicLayout
//       router.path = path
//       router.redirect = uri.redirect
//     } else {
//       router.component = () => require(`@/views/${path}`)
//       router.path = uri.uriCode || null
//     }
//     router.name = uri.uriCode || null
//     router.meta = {
//       title: uri.uriName,
//       icon: uri.icon || 'example'
//     }
//     if (uri.childs && uri.childs.length) {
//       router.children = filterAsyncRouter(uri.childs, level + 1)
//     }
//     routers.push(router)
//   })
//   return routers
// }
const permission = {
  state: {
    routers: constantRouterMap,
    addRouters: []
  },
  mutations: {
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers
      state.routers = constantRouterMap.concat(routers)
    }
  },
  actions: {
    GenerateRoutes ({ commit }, _) {
       return fetchUriTree().then((resp) => {
       console.log(resp)
        return new Promise(resolve => {
          const {
            result = []
          } = resp
          const accessedRouters = result// filterAsyncRouter(result, 1)
          commit('SET_ROUTERS', accessedRouters)
          resolve()
        })
      })
    }
  }
}

export default permission
