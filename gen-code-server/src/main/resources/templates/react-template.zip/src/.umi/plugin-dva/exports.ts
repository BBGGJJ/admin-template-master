
export { connect, useDispatch, useStore, useSelector } from 'D:/workspace/my-app-react/node_modules/dva';
export { getApp as getDvaApp } from './dva';
