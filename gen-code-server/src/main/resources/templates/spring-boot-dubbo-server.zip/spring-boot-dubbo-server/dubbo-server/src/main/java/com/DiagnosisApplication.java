package com.bj66nao.prod.center;

import com.bj66nao.central.api.dict.ProjectTypeEnums;
import org.apache.dubbo.config.spring.context.annotation.EnableDubbo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author：Joey
 * @Date: 2021/11/4
 * @Desc:
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableDubbo
@EnableScheduling
public class DiagnosisApplication {

    public static void main(String[] args) {
        SpringApplication.run(DiagnosisApplication.class, args);
    }
}
